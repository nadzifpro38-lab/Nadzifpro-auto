package com.nadzif.auto;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.BatteryManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String YT = "https://m.youtube.com/";
    private static final int BG = Color.rgb(7, 13, 25), PANEL = Color.rgb(23, 40, 66);
    private WebView web, ytWeb;
    private FrameLayout root;
    private LinearLayout yt;
    private LinearLayout block;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private boolean moving = false, passenger = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);

        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { pushUsb("init"); }
        });
        web.addJavascriptInterface(new Bridge(), "Nadzif");
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        buildYouTube();
        registerUsb();
        web.loadUrl("file:///android_asset/index.html");
    }

    private final BroadcastReceiver usbRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (a == null) return;
            if (a.equals(UsbManager.ACTION_USB_DEVICE_ATTACHED)) pushUsb("attached");
            else if (a.equals(UsbManager.ACTION_USB_DEVICE_DETACHED)) pushUsb("detached");
            else if (a.equals(Intent.ACTION_MEDIA_MOUNTED)) pushUsb("storage_in");
            else if (a.equals(Intent.ACTION_MEDIA_REMOVED) || a.equals(Intent.ACTION_MEDIA_UNMOUNTED) || a.equals(Intent.ACTION_MEDIA_EJECT)) pushUsb("storage_out");
            else pushUsb("power");
        }
    };

    private void registerUsb() {
        IntentFilter f = new IntentFilter();
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        IntentFilter m = new IntentFilter();
        m.addAction(Intent.ACTION_MEDIA_MOUNTED);
        m.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        m.addAction(Intent.ACTION_MEDIA_REMOVED);
        m.addAction(Intent.ACTION_MEDIA_EJECT);
        m.addDataScheme("file");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbRx, f, Context.RECEIVER_EXPORTED);
            registerReceiver(usbRx, m, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(usbRx, f);
            registerReceiver(usbRx, m);
        }
    }

    private void pushUsb(String event) {
        try {
            JSONObject o = new JSONObject();
            o.put("event", event);
            JSONArray arr = new JSONArray();
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um != null) for (UsbDevice d : um.getDeviceList().values()) {
                String n = null;
                try { n = d.getProductName(); } catch (Exception ignored) { }
                if (n == null || n.isEmpty()) n = String.format("USB %04x:%04x", d.getVendorId(), d.getProductId());
                arr.put(n);
            }
            o.put("devices", arr);
            Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                o.put("plug", b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0));
                o.put("level", lv < 0 ? -1 : lv * 100 / sc);
            }
            final String js = "window.onUsb&&onUsb(" + o.toString() + ")";
            web.post(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        String a = i.getAction();
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a) || UsbManager.ACTION_USB_ACCESSORY_ATTACHED.equals(a)) pushUsb("attached");
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbRx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private Button barBtn(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setBackgroundColor(PANEL);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(4, 4, 4, 4);
        b.setLayoutParams(p);
        return b;
    }

    private void buildYouTube() {
        yt = new LinearLayout(this);
        yt.setOrientation(LinearLayout.VERTICAL);
        yt.setBackgroundColor(BG);
        yt.setVisibility(View.GONE);

        FrameLayout area = new FrameLayout(this);
        ytWeb = new WebView(this);
        WebSettings s = ytWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(ytWeb, true);
        ytWeb.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                String h = r.getUrl().getHost();
                if (h != null && (h.endsWith("youtube.com") || h.endsWith("google.com") || h.endsWith("gstatic.com") || h.endsWith("googlevideo.com") || h.endsWith("youtu.be"))) return false;
                return true; // pautan luar disekat dalam mod kereta
            }
        });
        ytWeb.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
            }
            @Override public void onHideCustomView() { exitFullscreen(); }
        });
        area.addView(ytWeb, new FrameLayout.LayoutParams(-1, -1));

        block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER);
        block.setBackgroundColor(BG);
        block.setVisibility(View.GONE);
        TextView t = new TextView(this);
        t.setText("🚗 Video disembunyikan semasa kenderaan bergerak\nAudio terus dimainkan.");
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        t.setPadding(40, 20, 40, 20);
        block.addView(t);
        Button pb = new Button(this);
        pb.setText("Saya penumpang — tunjuk video");
        pb.setAllCaps(false);
        pb.setOnClickListener(v -> { passenger = true; applyMoving(); });
        block.addView(pb);
        area.addView(block, new FrameLayout.LayoutParams(-1, -1));
        yt.addView(area, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.rgb(11, 20, 36));
        bar.addView(barBtn("🏠 Utama", v -> ytWeb.loadUrl(YT)));
        bar.addView(barBtn("📺 Langganan", v -> ytWeb.loadUrl(YT + "feed/subscriptions")));
        bar.addView(barBtn("👤 Anda", v -> ytWeb.loadUrl(YT + "feed/you")));
        bar.addView(barBtn("◀ Balik", v -> { if (ytWeb.canGoBack()) ytWeb.goBack(); }));
        bar.addView(barBtn("✕ Tutup", v -> closeYouTube()));
        yt.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        root.addView(yt, new FrameLayout.LayoutParams(-1, -1));
    }

    private void applyMoving() {
        boolean hide = moving && !passenger;
        ytWeb.setVisibility(hide ? View.INVISIBLE : View.VISIBLE); // INVISIBLE = audio kekal
        block.setVisibility(hide ? View.VISIBLE : View.GONE);
    }

    private void exitFullscreen() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    private void openYouTube() {
        passenger = false;
        yt.setVisibility(View.VISIBLE);
        applyMoving();
        String u = ytWeb.getUrl();
        if (u == null || u.equals("about:blank")) ytWeb.loadUrl(YT);
    }

    private void closeYouTube() {
        exitFullscreen();
        ytWeb.loadUrl("about:blank");
        yt.setVisibility(View.GONE);
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (web != null) web.reload();
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    public class Bridge {
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void launch(String pkg, String fallbackUrl) {
            runOnUiThread(() -> {
                try {
                    Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i != null) { startActivity(i); return; }
                } catch (Exception ignored) { }
                if (fallbackUrl != null && fallbackUrl.length() > 0) openUrl(fallbackUrl);
            });
        }
        @JavascriptInterface public void navigate(double lat, double lng) {
            openUrl("google.navigation:q=" + lat + "," + lng);
        }
        @JavascriptInterface public void openYouTube() { runOnUiThread(MainActivity.this::openYouTube); }
        @JavascriptInterface public void setSpeed(int kmh) {
            runOnUiThread(() -> {
                boolean m = kmh >= 8;
                if (m != moving) { moving = m; if (!m) passenger = false; if (yt.getVisibility() == View.VISIBLE) applyMoving(); }
            });
        }
    }

    @Override public void onBackPressed() {
        if (customView != null) { exitFullscreen(); return; }
        if (yt.getVisibility() == View.VISIBLE) {
            if (ytWeb.canGoBack()) ytWeb.goBack(); else closeYouTube();
            return;
        }
        if (web != null) web.evaluateJavascript("(window.goBack&&goBack())", null); else super.onBackPressed();
    }
}
