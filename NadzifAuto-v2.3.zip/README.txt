NADZIF AUTO - Android starter project

This is an original starter app inspired by the general dashboard concept of the supplied reference APK. It does not include copied source code, branding, or proprietary assets from that APK.

Build automatically using a phone (no PC required):
1. Extract this ZIP on your phone.
2. In a browser, sign in to GitHub and create a NEW public or private repository.
3. Upload the CONTENTS of the NadzifAuto folder to the repository root (including the hidden .github folder and its workflows/build-apk.yml file).
4. Open the repository's Actions tab.
5. Select "Build NADZIF AUTO APK" and tap "Run workflow" (or wait for the first push build).
6. When the run finishes successfully, open that run and download the artifact named "Nadzif-Auto-debug-APK".
7. Extract the downloaded artifact ZIP and tap app-debug.apk to install. Android may ask you to allow installs from that browser/file manager.

Important:
- This is a debug APK for testing, not a Play Store release.
- The first build requires internet access and GitHub sign-in.
- The app is a starter prototype: dark/blue dashboard, clock/date, and shortcuts to Browser, YouTube and Maps. Browser/YouTube/Maps shortcuts open the corresponding apps or web links; this is not a full clone of AutoDeck.
- Android may restrict some video features while driving. Use video only when safely parked.

Package: com.nadzif.auto
Minimum Android: 6.0 (API 23)
Compile SDK: 35
Gradle: 8.9
